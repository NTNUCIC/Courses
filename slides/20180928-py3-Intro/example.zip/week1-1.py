'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w1練習1範例程式碼
輸入姓名、學號及5個成績(0~100,整數)
輸出姓名、學號、平均成績與等第

80以上:A
70以上不到80:B
60以上不到70:C
60以下:F
'''
name=input('輸入姓名:')#輸入姓名
num=input('輸入學號:')#輸入學號
score1=int(input('輸入分數1:'))#輸入是字串型態，要記得轉型
score2=int(input('輸入分數2:'))
score3=int(input('輸入分數3:'))
score4=int(input('輸入分數4:'))
score5=int(input('輸入分數5:'))
avg=(score1+score2+score3+score4+score5)/5#avg為平均分數
print('姓名:',name)
print('學號:',num)
print('平均成績:',avg)
if avg>=80:#if-elif-elif-else依序判斷，並且只會執行其中之一
    print('等第:A')#注意縮排
elif 80>avg>=70:#python中>等判斷可以連用，即80>avg and avg>=70
    print('等第:B')
elif 70>avg>=60:
    print('等第:C')
else:
    print('等第:F')