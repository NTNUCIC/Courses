'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w4練習1範例程式碼

一位農夫帶著一隻狗，一隻雞，一包米要渡河，
可是船只能容納農夫和一樣東西，
而且又要避免狗吃雞，雞吃米，
你可以幫助農夫想想嗎？

輸入農夫外要移動的物品
顯示河兩岸分別有哪些(船、農夫、米、雞、狗)
若狗雞同岸無農夫或雞米同岸無農夫則顯示遊戲失敗
全數抵達對岸顯示過關

需加入輸入防呆
'''
#10/19練習
#https://github.com/vbscript055246/WTF_this_code_writing/blob/master/quiz_temp.py?fbclid=IwAR2g-qhReKsFBLbXD5_Iw0Bq4HlxA9Kmn4QGnh6b8Wfx0aG-AEilMBKeA4I
import os
relate = {'狗': '雞', '雞': '米', '米': None}
bad_event = {'狗': "無情的做成虛擬雞", '雞': "殘酷的煮成花生米", '米': None}
A_side = ['狗', '雞', '米']
B_side = []
boat_side = True
while len(B_side) != 3:
    if boat_side:
        for item in B_side:
            if relate[item] in B_side:
                print("{}把{}{}吃了~QAQ".format(item, relate[item], bad_event[item]))
                exit(0)
        print("船現在在A岸:")
        for i in range(1, len(A_side)+1):
            print("{}. {}".format(i, A_side[i-1]))
        num = int(input("請問誰要上船呢? 輸入0直接到另一岸\n"))
        if len(A_side) < num or num < 0:
            continue
        elif num == 0:
            boat_side = not boat_side
            continue
        B_side.append(A_side[num-1])
        del A_side[num-1]
    else:
        for item in A_side:
            if relate[item] in A_side:
                print("{}把{}{}吃了~QAQ".format(item, relate[item], bad_event[item]))
                exit(0)
        print("船現在在B岸:")
        for i in range(1, len(B_side)+1):
            print("{}. {}".format(i, B_side[i-1]))
        num = int(input("請問誰要上船呢? 輸入0直接到另一岸\n"))
        if len(B_side) < num or num < 0:
            continue
        elif num == 0:
            boat_side = not boat_side
            continue
        A_side.append(B_side[num - 1])
        del B_side[num - 1]
    boat_side = not boat_side
    os.system('cls')
print("破關囉~!!!")