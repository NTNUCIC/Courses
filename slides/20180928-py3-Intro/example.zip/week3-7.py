'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w3練習7範例程式碼
輸入非0整數(輸入0結束)
輸出正數(依輸入順序)

輸入防呆
'''
list1=[]#建立空串列
while True:#輸入非0整數(輸入0結束)
    try:#防呆，若無法try則執行except
        i=int(input())#輸入非0整數(輸入0結束)
        if i==0:#輸入0結束
            break
        elif i>0:#若為正數則加入串列
            list1.append(i)
    except:
        print('INPUT ERROR!')#寫程式時適當加入錯誤訊息可幫助除錯
for i in range(len(list1)):#依序輸出串列
    print(list1[i])