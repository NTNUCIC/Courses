'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w3練習5範例程式碼
輸入一個正整數N
輸出f(N)

費氏數列f(N)定義如下
f(0)=0, f(1)=1, f(n)=f(n-1)+f(n-2)
'''
n=int(input())
a=0#f0
b=1#f1
c=1#f2
if n==0:
    print('f(N)=0')
elif n==1:
    print('f(N)=1')
else:
    for i in range(n-2):#重複n-2次
        #     a:fn-2,b:fn-1,c:fn
        a=b#  a:fn-1,b:fn-1,c:fn
        b=c#  a:fn-1,b:fn,  c:fn
        c=a+b#a:fn-1,b:fn,  c:fn+1 ##c等於f(2+ n-2)等於fn(n>=2)
    print('f(N)=%d'%c)#輸出fn