'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#DICTIONARY
字典名稱={鍵1:值1,鍵2:值2,...}
#鍵不可重複(前項被覆蓋)
#元組用小括號
#串列用中括號
#字典用大括號
'''
dict1={'數學':98,'國文':75,'英文':30}
print('數學:',dict1['數學'])

'''
#進階操作                   ##注意位置從0開始(0~n-1)
len(dict1)                  #取得長度
dict1.clear()               #清空
dict1.copy()                #複製
dict1.get(key,value)        #取得鍵對應值，若不存在則回傳參數值
key in dict1                #檢查鍵是否存在，回傳bool
dict1.items()               #取得以鍵值對為元素的組合
dict1.keys()                #取得以鍵為元素的組合
dict1.setdefault(key,value) #取得鍵對應值，若不存在則新增鍵值對
dict1.values()              #取得以值為元素的組合
'''

dict1['社會'] = 71#更改數值，若無鍵則鍵值對加入字典
dict1['自然'] = 98

#讀取方法1，keys&values
listkey=list(dict1.keys())#使用list()轉為list型態
listvalue=list(dict1.values())
for i in range(len(listkey)):
    print('%s的成績為%d分'%(listkey[i],listvalue[i]))

#讀取方法2，items
listitem=dict1.items()
for name,score in listitem:
    print("%s的成績為%d分"%(name,score))

print('數學:',dict1.get('數學',0))#
print('程式:',dict1.setdefault('程式',100))#