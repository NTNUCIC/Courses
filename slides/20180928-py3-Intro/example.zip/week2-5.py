'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w2練習5範例程式碼
輸入姓名學號及數個成績(直到輸入-1結束)
輸出姓名學號、成績數量、平均成績
'''
str1=input('輸入姓名:')
str2=input('輸入學號:')
print('輸入成績(輸入-1結束)')
s=0#總和設為0
num=0#數量設為0
a=int(input())#先輸入1次成績
while (a!=-1):#若不為-1則繼續
    s+=a#s=s+a
    num+=1#num=num+1
    a=int(input())#輸入下1次成績
print('姓名:{}'.format(str1))
print('學號:{}'.format(str2))
print('成績數量:{}'.format(num))
if(num):#若num非0則為真(True)，輸出平均
    print('平均成績:{:6.2f}'.format(s/num))