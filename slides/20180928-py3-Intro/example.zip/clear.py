'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

import os#要使用system('clear')在程式最上面打這列
os.system('clear')#程式執行中清空輸出

#若使用anaconda3 spyder
#在右方輸入 clear clear() %clear 都能清空輸出