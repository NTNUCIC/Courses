'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#算數運算
加+
減-
乘*
除/
除：取整數//
除：取餘數%
次方**
'''
a=1+2
print('a:',a)
b=4-2
print('b:',b)
c=8*7
print('c:',c)
d=20/3
print('d:',d)
e=20//3
print('e:',e)
f=20%3
print('f:',f)
g=5**2
print('g:',g)

'''
#邏輯運算
and
or
not
'''
print('True and True:',True and True)
print('True and False:',True and False)
print('False and True:',False and True)
print('False and False:',False and False)
print('True or True:',True or True)
print('True or False:',True or False)
print('False or True:',False or True)
print('False or False:',False or False)
print('not True:',not True)
print('not False:',not False)

'''
#複合指定運算子
+=
-=
*=
/=
//=
%=
**=
'''
a=1
b=2
a=a+b
print(a)
a=1
b=2
a+=b#a+=b即為a=a+b,另與-= *=等用法相同
print(a)