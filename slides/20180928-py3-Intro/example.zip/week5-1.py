'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w5練習1範例程式碼

輸入溫度
輸出轉換後溫度

使用2函式供使用者選擇
def ftoc(f):
def ctof(c):
'''
#10/26練習
def ftoc(f):
    return (f-32)*5/9
def ctof(c):
    return c*1.8+32
a=input()
b=input()
if a=='1':
    print('ftoc:',ftoc(int(b)))
else :
    print('ctof:',ctof(int(b)))
