'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w3練習8範例程式碼
輸入5整數
輸出排序後的數列

輸入1整數(輸入X離開)
輸出最後5個輸入的整數排序後的數列
'''
list1=[int(i) for i in input().split()]#輸入並轉成整數
list2=sorted(list1)#儲存排序後list1
for i in range(5):#輸出排序後的數列
    print(list2[i])
n=input()#輸入1整數(輸入X離開)
while n!='X':
    n=int(n)#n轉整數
    del list1[0]#刪除舊list第一項
    list1.append(n)#將新數加入list最後
    list2=sorted(list1)#儲存排序後list1
    for i in range(5):#輸出排序後的數列
        print(list2[i])
    n=input()#輸入1整數(輸入X離開)