'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#file
讀檔f=open('filename','r')
寫檔f=open('filename','w')#複寫，開新檔
寫檔f=open('filename','a')#增加在檔案末尾
'''
#####

print('\ninput5-1.txt, r:')
f=open('input5-1.txt','r')

for line in f:
    print(line,end='')

f.close()#關檔很重要

#####

print('\ninput5-1.txt, r:')
print('\noutput5-1.txt, w:')
f1=open('input5-1.txt','r')
f2=open('output5-1.txt','w')

for line in f1:
    print(line,end='')
    f2.write(line)

f1.close()#關檔很重要
f2.close()#關檔很重要

#####

print('\ninput5-1.txt, r:')
with open('input5-1.txt','r') as f:
    for line in f:
        print(line,end='')

#####

print('\ninput5-1.txt, r:')
print('\ninput5-1.txt, r:')
f1=open('ansi.txt','r',encoding='cp950')
f2=open('utf8.txt','r',encoding='UTF-8')
f1.close()#關檔很重要
f2.close()#關檔很重要