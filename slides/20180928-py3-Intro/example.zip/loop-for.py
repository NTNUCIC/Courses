'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#FOR迴圈
for 變數 in 序列:
    程式區塊
    注意縮排
'''

list1=['A1','B2','C3']
for i in list1:#執行list1元素數量次迴圈，依次將i設為list1各元素
    print(i)

'''
#break 直接離開迴圈
#continue 跳過這一圈
#while中的break continue用法同for
'''
print('break:')
for i in range(10):#for可以直接用range
    if i==5:#雙等於是數學上的等於，單等於是將右方指定給左方
        break#通常break continue會搭配if使用
    print(i)#注意縮排，這列不在if中

print('continue:')
for i in range(10):#可以直接用range來取代list
    if i==5:
        continue#通常break continue會搭配if使用
    print(i)#注意縮排，這列不在if中

for i in range(5):#for-else迴圈
    if i>5:
        break
else:#for-else迴圈，若無break，執行else
    print('FOR NO BREAK')