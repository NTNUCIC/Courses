'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#funtion
def myfuncname(參數1,參數2,...):#參數可有(數量不限)可無
    #函式區塊
    return 回傳值1,回傳值2, ...#回傳值可有(數量不限)可無
'''

'''
#內建函式
abs(x)			#取得x絕對值
chr(x)			#取得整數x的字元
divmod(x,y)		#取得x除以y的商及餘數的元組
float(x)		#將x轉成float
hex(x)			#將x轉成16進制數字
int(x)			#將x轉成整數
len(x)			#取得元素數
max(參數串列)	#取得參數中最大值
min(參數串列)	#取得參數中最小值
oct(x)			#將x轉成8進制數字
ord(x)			#
pow(x,y)		#取得x的y次方
round(x)		#4捨6入取得x近似值
sorted(串列)	#由小到大排序
str(x)			#將x轉成字串
sum(串列)		#計算串列元素的總和
type(物件)		#取得物件資料型態
'''
#####

print('helloworld:')

def helloworld():
    print('hello world!')

helloworld()#use function helloworld()

#####

print('add2num:')

def add2num(a,b):
    return a+b

a=int(input())
b=int(input())
print(add2num(a,b))

#####

print('add5:')

def add5(a,b=5):
    return a+b

a=int(input())
print(add5(a))

a=int(input())
b=int(input())
print(add5(a,b))

#####

print('myadd:')

def myadd(*args):
    s=0
    for i in args:
        s+=i
    return s

a=[int(i) for i in input().split()]
print(myadd(*a))

#####