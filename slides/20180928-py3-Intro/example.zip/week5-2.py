'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w5練習2範例程式碼

輸出input5-2.txt數字總和
'''
s=0
with open('input5-2.txt','r') as f:
    for line in f:
        s+=int(line)
print(s)