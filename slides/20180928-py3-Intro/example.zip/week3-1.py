'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w3練習1範例程式碼
輸入一正整數N
輸出N的標準分解式
'''
n=int(input('輸入正整數N:'))
while n>1:#直到n被除到1
    for i in range(2,n+1):#檢查2~n能否整除
        c=0#計數歸零
        if n%i==0:#若整除
            while n%i==0:#直到i除盡
                n/=i#n=n/i
                c+=1#c=c+1
            print('{}^{}'.format(i,c))#輸出 i ^ c