'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#WHILE迴圈
while 條件式:
    程式區塊
    注意縮排
'''
while True:
    print('XD\n')
    break#若無break則產生無窮迴圈

n=0
while n<10:#每次執行前都會檢查條件式
    print(n)
    n+=1#n=n+1

'''
#WHILE迴圈-防呆
輸入整數
'''
while True:
    try:#嘗試
        a=int(input())#失敗直接跳至except
        break#離開while
    except:#try失敗則執行except
        print('NOT INT TYPE')