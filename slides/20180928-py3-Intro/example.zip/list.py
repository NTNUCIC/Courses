'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#LIST
串列名稱=[元素1,元素2,元素3, ... ...]
list是保留字，宣告變數時要注意
'''
list1=[1,2,3]#整數串列
list2=['QAQ','OWO','>.<']#字串串列
list3=[1,'NTNUCIC',True]#可以放不同型態的資料，但不建議這麼做
list4=[list1,list2,list3]#串列的元素可以是串列
list5=[[1,2,3],['QAQ','OWO','>.<'],[1,'NTNUCIC',True]]#與list4相同
list5=[1,2,3,'QAQ','OWO','>.<',1,'NTNUCIC',True]#與list4不同

'''
#進階操作               ##注意串列位置從0開始(0~n-1)
list1[n1]               #取出第n1個元素
list1[n1:n2]            #取出n1~n2-1
list1[n1:n2:n3]         #取出n1~n2-1,間隔n3
del list1[n1:n2]        #刪除n1~n2-1
del list1[n1:n2:n3]     #刪除n1~n2-1,間隔n3
len(list1)              #取得串列元素數
min(list1)              #取得最小值##請確認串列內元素型態相同
max(list1)              #取得最大值##請確認串列內元素型態相同
list1.index(n1)         #第一次出現n1的index值(位置從0開始)
list1.count(n1)         #元素n1出現次數
list1.append(n1)        #將n1做為元素加入list1最後##若加入串列，則形成二維串列，如list5
list1.extend(x)         #將x中的元素逐一加入list1最後
list1.insert(index1,n1) #在位置index1加入n1元素
list1.pop()             #取出最後一個元素並從串列中移除
list1.remove(n1)        #移除第一個n1元素
list1.reverse()         #反轉串列順序
list1.sort()            #由小到大排序
##取出後可以直接使用，也可以指定給另一個串列變數
'''