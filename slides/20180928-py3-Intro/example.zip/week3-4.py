'''
國立臺灣師範大學資訊研究社
107學年度第1學期社課講義
'''

'''
#w3練習4範例程式碼
輸入一正整數N
輸出小於N的所有質數
'''
n=int(input('輸入整數N'))#輸入整數N
for i in range(2,n):#i從2到n-1
    for j in range(2,i):#for-else迴圈，j從2到i-1，檢查i是否質數
        if i%j==0:#i有>=2的因數，i非質數
            break#離開for-else迴圈
    else:#for-else迴圈，若無break，執行else
        print(i)#輸出質數i