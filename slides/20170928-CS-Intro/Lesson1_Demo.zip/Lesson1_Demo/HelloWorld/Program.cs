﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello World!");
            Console.Write("Hello C#!");
            Console.ReadLine();

            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello C#!");
            Console.ReadLine();

            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello C#!");
            Console.ReadLine();

            Console.WriteLine("Hello World!\nHello C#!");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Hello World!\tHello C#!");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\\Hello World/\\Hello C#/");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("\"Hello World! Hello C#!\"");
            Console.ReadLine();
            Console.Clear();
        }
    }
}
