﻿using System;

namespace LoveLetter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dear 西夏普：");
            Console.ReadLine();

            Console.WriteLine("雖然在一開始，");
            Console.WriteLine("我並不太喜歡你，");
            Console.WriteLine("但經過一段時間的相處後，");
            Console.WriteLine("發現你的貼心無所不在。");
            Console.ReadLine();

            Console.WriteLine("離了你讓我手足無措，");
            Console.WriteLine("平常五分鐘就能完成的事情，");
            Console.WriteLine("因為沒有你從旁協助，");
            Console.WriteLine("居然花了我半小時......");
            Console.ReadLine();

            Console.WriteLine("這時我才意識到，");
            Console.WriteLine("原來我已經喜歡上你了！");
            Console.ReadLine();

            Console.WriteLine("請問，");
            Console.WriteLine("你願意跟我一起，");
            Console.WriteLine("在寫程式這條路上，");
            Console.WriteLine("一直走下去嗎？");
            Console.ReadLine();

            Console.WriteLine("P.S. 我沒有找工具人的意思，真的！");
            Console.ReadLine();

            Console.WriteLine("\n\n愛你的 Programmer :)");
            Console.ReadLine();
        }
    }
}
