﻿using System;

namespace HourGlass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("XXXXXXXXXXXX");
            Console.WriteLine(" \\*******/");
            Console.WriteLine("  \\*****/");
            Console.WriteLine("   \\***/");
            Console.WriteLine("    \\*/");
            Console.WriteLine("    / \\");
            Console.WriteLine("   /   \\");
            Console.WriteLine("  /     \\");
            Console.WriteLine(" /       \\");
            Console.WriteLine("XXXXXXXXXXXX");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("XXXXXXXXXXXX");
            Console.WriteLine(" \\       /");
            Console.WriteLine("  \\*****/");
            Console.WriteLine("   \\***/");
            Console.WriteLine("    \\*/");
            Console.WriteLine("    / \\");
            Console.WriteLine("   /   \\");
            Console.WriteLine("  /     \\");
            Console.WriteLine(" /*******\\");
            Console.WriteLine("XXXXXXXXXXXX");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("XXXXXXXXXXXX");
            Console.WriteLine(" \\       /");
            Console.WriteLine("  \\     /");
            Console.WriteLine("   \\***/");
            Console.WriteLine("    \\*/");
            Console.WriteLine("    / \\");
            Console.WriteLine("   /   \\");
            Console.WriteLine("  /*****\\");
            Console.WriteLine(" /*******\\");
            Console.WriteLine("XXXXXXXXXXXX");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("XXXXXXXXXXXX");
            Console.WriteLine(" \\       /");
            Console.WriteLine("  \\     /");
            Console.WriteLine("   \\   /");
            Console.WriteLine("    \\*/");
            Console.WriteLine("    / \\");
            Console.WriteLine("   /***\\");
            Console.WriteLine("  /*****\\");
            Console.WriteLine(" /*******\\");
            Console.WriteLine("XXXXXXXXXXXX");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("XXXXXXXXXXXX");
            Console.WriteLine(" \\       /");
            Console.WriteLine("  \\     /");
            Console.WriteLine("   \\   /");
            Console.WriteLine("    \\ /");
            Console.WriteLine("    /*\\");
            Console.WriteLine("   /***\\");
            Console.WriteLine("  /*****\\");
            Console.WriteLine(" /*******\\");
            Console.WriteLine("XXXXXXXXXXXX");
            Console.ReadLine();

            Console.WriteLine("時間到！");
            Console.ReadLine();
        }
    }
}
