﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emoticon
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========顏文字清單==========");

            Console.WriteLine("~喜~\n");
            Console.WriteLine("(*´ w `)~");
            Console.WriteLine("\\(*．▽．)/");
            Console.WriteLine("\\(●´ u `●)/");
            Console.WriteLine("(\\\\´\\3\\`\\\\)");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("~怒~\n");
            Console.WriteLine("(#`A´)/");
            Console.WriteLine("<(#`皿´)>");
            Console.WriteLine("\\(#`^´)/");
            Console.WriteLine("(+ ˋAˊ) ");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("~哀~\n");
            Console.WriteLine("(ˊ;ω;ˋ ) ");
            Console.WriteLine("(╥﹏╥)");
            Console.WriteLine("(T﹏T)");
            Console.WriteLine("(/O n O\\)");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("~樂~\n");
            Console.WriteLine("(*´ w `)~");
            Console.WriteLine("\\(*．▽．)/");
            Console.WriteLine("\\(●´ u `●)/");
            Console.WriteLine("(\\\\´\\3\\`\\\\)");

            Console.ReadLine();
        }
    }
}
