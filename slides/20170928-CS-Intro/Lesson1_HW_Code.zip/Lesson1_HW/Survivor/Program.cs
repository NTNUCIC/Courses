﻿using System;

namespace Survivor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==========荒野探險日記==========\n");

            Console.WriteLine("這天，23歲女性的Kei獨自踏上了遠行的道路，成為了荒野探險者中的一員");
            Console.WriteLine("\n=============================\n\n");

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("荒野探險第十一天\n一群穿著西裝的喪屍出現了，是傳說中的喪屍合唱團，他們開始了大合唱，「啊~~~啊~~~」");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第二十八天\n一群穿著西裝的喪屍出現了，是傳說中的喪屍合唱團，他們開始了大合唱，「啊~~~啊~~~」");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第四十八天\n一隻喪屍「啊...啊...」走了過來，我用板凳暴了他的頭");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第五十六天\n「嘶～」背後傳來聲響，嚇的我連滾帶爬遠遠的逃離這裡");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第六十二天\n今天是喪屍教會一年一度的重大日子\n一般來說倖存者這時會躲在家裡向上天祈求\n不過我參與了遊行，作為祭品");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第八十三天\n花盆，完美無瑕的花盆，可以用來砸在喪屍頭上");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第一百零二天\n夜晚在荒野中升起了篝火\n路上遇到的老人說起了喪屍在大城市爆發的情況\n「他們依然遵守著交通號誌，那時我們在十字路口穿梭\n嘲笑過不了馬路的喪屍是那時候的樂趣之一」");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("荒野探險第一百零六天\n被喪屍咬死了");
            Console.WriteLine("\n");
            Console.ReadLine();

            Console.WriteLine("~完~");
            Console.ReadLine();
        }
    }
}
